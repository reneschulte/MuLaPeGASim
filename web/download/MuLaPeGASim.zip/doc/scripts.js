function docChanged(text)
{
	document.writeln(text + this.document.lastModified);
}

function checkTop(doc)
{
	if (doc.self == doc.top) doc.location.href = "index.htm";
}