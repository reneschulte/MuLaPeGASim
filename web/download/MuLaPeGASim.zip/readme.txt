How to use:
�����������

You can open the manual in MuLaPeGASim by pressing "F1" on your keyboard.


Legal Stuff:
������������

The whole program, source code and algorithms are fully owned by Rene Schulte and Torsten B�r! Copying of the software for non (!) commercial purposeses is allowed. If you want to use the program for commercial purposes please contact the authors first! This software is Mailware ;-). This means, if you use the program please write an email to the authors with your comments about the tool, suggestions or anything else you would like to share with the authors.
Money is also always welcome! :o)


Contact:
��������
Rene Schulte: mulapegasim@rene-schulte.info
Torsten Baer: mulapegasim@baer-torsten.info

� 2004 Rene Schulte and Torsten Baer