1. Start Setup.exe to install MuLaPeGASim to your computer.
2. Doubleclick on MuLaPeGASim to run the program.
3. After the installation is finished, you can find a link to the manual in your "Programs"->"MuLaPeGASim" folder.

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

You can uninstall the application at any time. Go to:
Start -> Control panel -> Software -> Select MuLaPeGaSim and click remove

++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Contact:
��������
Rene Schulte: mulapegasim@rene-schulte.info
Torsten Baer: mulapegasim@baer-torsten.info

� 2004 Rene Schulte and Torsten Baer
